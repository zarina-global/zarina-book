"use client";

import { useState } from "react";

const translations = {
  uz: {
    title: "Maqsad – Jarayon = Natija",
    subtitle: "Zarina Global Gnostic manifesti — ong, energiya va moddaning yangi qonunlari",
    buy: "Sotib olish",
    or: "yoki",
    audioLabel: "Audio namunasi",
    videoLabel: "Video namunasi",
    toc: "Mundarija",
    about: "Kitob haqida",
    author: "Muallif haqida",
    testimonials: "Fikrlar",
    faq: "Ko‘p so‘raladigan savollar",
    lang: "Til",
    premium: "Premium paket (PDF + Audio + Video)",
    pdfOnly: "Faqat PDF versiya",
    audioOnly: "Faqat audio versiya",
    videoOnly: "Faqat video paket",
    secure: "Xarid xavfsiz to‘lov orqali amalga oshiriladi",
    contact: "Bog‘lanish",
    rights: "© Zarina Global Gnostic. Barcha huquqlar himoyalangan.",
  },
  ru: {
    title: "Цель – Процесс = Результат",
    subtitle: "Манифест Zarina Global Gnostic — новые законы сознания, энергии и материи",
    buy: "Купить",
    or: "или",
    audioLabel: "Аудио-пример",
    videoLabel: "Видео-пример",
    toc: "Оглавление",
    about: "О книге",
    author: "Об авторе",
    testimonials: "Отзывы",
    faq: "FAQ",
    lang: "Язык",
    premium: "Премиум пакет (PDF + Аудио + Видео)",
    pdfOnly: "Только PDF",
    audioOnly: "Только аудио",
    videoOnly: "Только видео пакет",
    secure: "Оплата производится через защищённый шлюз",
    contact: "Контакты",
    rights: "© Zarina Global Gnostic. Все права защищены.",
  },
  en: {
    title: "Goal – Process = Result",
    subtitle: "Zarina Global Gnostic Manifest — new laws of mind, energy and matter",
    buy: "Buy now",
    or: "or",
    audioLabel: "Audio sample",
    videoLabel: "Video sample",
    toc: "Table of Contents",
    about: "About the Book",
    author: "About the Author",
    testimonials: "Testimonials",
    faq: "FAQ",
    lang: "Language",
    premium: "Premium bundle (PDF + Audio + Video)",
    pdfOnly: "PDF only",
    audioOnly: "Audio only",
    videoOnly: "Video bundle",
    secure: "Secure checkout",
    contact: "Contact",
    rights: "© Zarina Global Gnostic. All rights reserved.",
  },
};

export default function Page() {
  const [lang, setLang] = useState<"uz"|"ru"|"en">("uz");
  const t = (translations as any)[lang];

  const checkout = {
    premium: "https://example.com/premium",
    pdf: "https://example.com/pdf",
    audio: "https://example.com/audio",
    video: "https://example.com/video",
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-bold">Z</div>
          <div>
            <p className="text-sm uppercase tracking-widest text-white/60">Zarina Global Gnostic</p>
            <h1 className="text-lg font-semibold">{t.title}</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-sm text-white/70 mr-2">{t.lang}</label>
          <select value={lang} onChange={(e)=>setLang(e.target.value as any)} className="bg-black/30 border border-white/20 rounded-md px-3 py-1.5 text-sm">
            <option value="uz">UZ</option>
            <option value="ru">RU</option>
            <option value="en">EN</option>
          </select>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pb-10 pt-6 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-3xl md:text-5xl font-semibold leading-tight">{t.title}</h2>
          <p className="mt-4 text-white/80">{t.subtitle}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href={checkout.premium} className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 transition font-semibold">{t.premium}</a>
            <span className="self-center text-white/70">{t.or}</span>
            <a href={checkout.pdf} className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 transition">{t.pdfOnly}</a>
            <a href={checkout.audio} className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 transition">{t.audioOnly}</a>
            <a href={checkout.video} className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 transition">{t.videoOnly}</a>
          </div>
          <p className="mt-3 text-xs text-white/70">{t.secure}</p>
        </div>
        <div className="relative">
          <div className="aspect-[3/4] rounded-3xl bg-white/10 border border-white/20 shadow-xl overflow-hidden">
            <img src="/cover.png" alt="Cover" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Media samples */}
      <section className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-8">
        <div className="bg-white/10 border border-white/20 rounded-2xl p-5">
          <h4 className="font-semibold mb-2">{t.audioLabel}</h4>
          <audio controls className="w-full">
            <source src="/audio-sample.mp3" type="audio/mpeg" />
            Your browser does not support the audio element.
          </audio>
          <p className="text-xs text-white/70 mt-2">UZ/RU/EN ovozli namuna — keyin yuklanadi</p>
        </div>
        <div className="bg-white/10 border border-white/20 rounded-2xl p-5">
          <h4 className="font-semibold mb-2">{t.videoLabel}</h4>
          <div className="aspect-video rounded-xl overflow-hidden border border-white/10">
            <iframe
              className="w-full h-full"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              title="Video sample"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
          <p className="text-xs text-white/70 mt-2">Har bob uchun 1 ta video — premium paket ichida</p>
        </div>
      </section>

      {/* TOC */}
      <section className="max-w-6xl mx-auto px-6 mt-10">
        <h3 className="text-xl font-semibold mb-3">{t.toc}</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-4">
              <p className="text-sm font-semibold">{i+1}-bob</p>
              <p className="text-sm text-white/80 mt-1">Bob tavsifi — qisqa izoh (UZ/RU/EN)</p>
            </div>
          ))}
        </div>
      </section>

      {/* About & Author */}
      <section className="max-w-6xl mx-auto px-6 mt-10 grid md:grid-cols-2 gap-8">
        <div className="bg-white/10 border border-white/20 rounded-2xl p-6">
          <h3 className="text-xl font-semibold mb-2">{t.about}</h3>
          <p className="text-white/80 text-sm leading-relaxed">
            “{t.title}” — ong, energiya va moddaning yangi uyg‘unlik modeli. Kitob 0 so‘mdan kvadrilion natijaga olib boruvchi falsafa va amaliy tizimni o‘z ichiga oladi. Har bir bob — energiya portali.
          </p>
        </div>
        <div className="bg-white/10 border border-white/20 rounded-2xl p-6">
          <h3 className="text-xl font-semibold mb-2">{t.author}</h3>
          <p className="text-white/80 text-sm leading-relaxed">
            Zarina Komilovna — Zarina Global Gnostic tizimining asoschisi. Yozuvchi, dizayner va gnostik rahbar. Uning maqsadi — inson ongini uyg‘otish va global uyg‘onish tizimini yaratish.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-6xl mx-auto px-6 mt-12 py-10">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <p className="text-sm">{t.contact}: support@zarinagnostic.example</p>
            <p className="text-xs text-white/60 mt-1">{t.rights}</p>
          </div>
          <div className="flex items-center gap-2 text-xs text-white/70">
            <span>Terms</span>
            <span>•</span>
            <span>Privacy</span>
            <span>•</span>
            <span>Refunds</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
