export const metadata = {
  title: "Zarina Global — Book Platform",
  description: "Maqsad – Jarayon = Natija | Zarina Global Gnostic",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="uz">
      <body>{children}</body>
    </html>
  );
}
